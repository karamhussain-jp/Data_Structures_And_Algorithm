#include <iostream>
#include <string>
using namespace std;

struct AlertNode
{
    int alertID;
    string type;
    string message;
    AlertNode* next;
};

class Stack
{
private:
    AlertNode* top;
    int count;

public:

    Stack()
    {
        top = NULL;
        count = 0;
    }

    void Push(AlertNode* alert)
    {
        alert->next = top;
        top = alert;
        count++;
    }

    AlertNode* Pop()
    {
        if (IsEmpty())
        {
            return NULL;
        }

        AlertNode* temp = top;
        top = top->next;
        temp->next = NULL;
        count--;

        return temp;
    }

    AlertNode* GetTopValue()
    {
        return top;
    }

    bool IsEmpty()
    {
        return top == NULL;
    }

    bool IsNotEmpty()
    {
        return top != NULL;
    }

    void PrintStack()
    {
        if (IsEmpty())
        {
            cout << "No security alerts." << endl;
            return;
        }

        AlertNode* temp = top;

        while (temp != NULL)
        {
            cout << "Alert ID: " << temp->alertID << endl;
            cout << "Type: " << temp->type << endl;
            cout << "Message: " << temp->message << endl;
            cout << "-------------------" << endl;

            temp = temp->next;
        }
    }

    Stack(const Stack& other)
    {
        top = NULL;
        count = 0;

        AlertNode* temp = other.top;
        AlertNode* last = NULL;

        while (temp != NULL)
        {
            AlertNode* newAlert = new AlertNode;

            newAlert->alertID = temp->alertID;
            newAlert->type = temp->type;
            newAlert->message = temp->message;
            newAlert->next = NULL;

            if (top == NULL)
            {
                top = newAlert;
            }
            else
            {
                last->next = newAlert;
            }

            last = newAlert;
            temp = temp->next;
            count++;
        }
    }

    Stack& operator=(const Stack& other)
    {
        if (this != &other)
        {
            while (!IsEmpty())
            {
                AlertNode* temp = Pop();
                delete temp;
            }

            AlertNode* temp = other.top;
            AlertNode* last = NULL;

            while (temp != NULL)
            {
                AlertNode* newAlert = new AlertNode;

                newAlert->alertID = temp->alertID;
                newAlert->type = temp->type;
                newAlert->message = temp->message;
                newAlert->next = NULL;

                if (top == NULL)
                {
                    top = newAlert;
                }
                else
                {
                    last->next = newAlert;
                }

                last = newAlert;
                temp = temp->next;
                count++;
            }
        }

        return *this;
    }

    ~Stack()
    {
        while (!IsEmpty())
        {
            AlertNode* temp = Pop();
            delete temp;
        }
    }
};

int main()
{
    Stack alerts;

    AlertNode* alert1 = new AlertNode;
    alert1->alertID = 101;
    alert1->type = "Firewall Alert";
    alert1->message = "Unauthorized connection detected.";

    AlertNode* alert2 = new AlertNode;
    alert2->alertID = 102;
    alert2->type = "Port Scan";
    alert2->message = "Multiple ports scanned.";

    AlertNode* alert3 = new AlertNode;
    alert3->alertID = 103;
    alert3->type = "Login Alert";
    alert3->message = "Multiple failed login attempts.";

    AlertNode* alert4 = new AlertNode;
    alert4->alertID = 104;
    alert4->type = "Malware Alert";
    alert4->message = "Malware activity detected.";

    alerts.Push(alert1);
    alerts.Push(alert2);
    alerts.Push(alert3);
    alerts.Push(alert4);

    cout << "All Security Alerts:" << endl;
    alerts.PrintStack();

    cout << endl;

    cout << "Top Alert:" << endl;

    AlertNode* topAlert = alerts.GetTopValue();

    if (topAlert != NULL)
    {
        cout << topAlert->alertID << " "
             << topAlert->type << " "
             << topAlert->message << endl;
    }

    cout << endl;

    cout << "Processing Alert:" << endl;

    AlertNode* processedAlert = alerts.Pop();

    if (processedAlert != NULL)
    {
        cout << "Processed: "
             << processedAlert->type << endl;

        delete processedAlert;
    }

    cout << endl;

    cout << "Remaining Alerts:" << endl;
    alerts.PrintStack();

    cout << endl;

    if (alerts.IsEmpty())
    {
        cout << "Alert Stack is empty." << endl;
    }
    else
    {
        cout << "Alert Stack is not empty." << endl;
    }

    return 0;
}
