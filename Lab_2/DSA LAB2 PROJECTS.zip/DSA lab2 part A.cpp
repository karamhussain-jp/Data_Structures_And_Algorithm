#include <iostream>
#include <string>
using namespace std;

struct BookNode
{
    int bookID;
    string title;
    string author;
    BookNode* next;
};

class Stack
{
private:
    BookNode* top;
    int count;

public:

    Stack()
    {
        top = NULL;
        count = 0;
    }

    void Push(BookNode* book)
    {
        book->next = top;
        top = book;
        count++;
    }

    BookNode* Pop()
    {
        if (IsEmpty())
        {
            return NULL;
        }

        BookNode* temp = top;
        top = top->next;
        temp->next = NULL;
        count--;

        return temp;
    }

    BookNode* GetTopValue()
    {
        return top;
    }

    bool IsEmpty()
    {
        return top == NULL;
    }

    bool IsNotEmpty()
    {
        return top != NULL;
    }

    void PrintStack()
    {
        if (IsEmpty())
        {
            cout << "Stack is empty." << endl;
            return;
        }

        BookNode* temp = top;

        while (temp != NULL)
        {
            cout << "Book ID: " << temp->bookID << endl;
            cout << "Title: " << temp->title << endl;
            cout << "Author: " << temp->author << endl;
            cout << "-------------------" << endl;

            temp = temp->next;
        }
    }

    Stack(const Stack& other)
    {
        top = NULL;
        count = 0;

        BookNode* temp = other.top;
        BookNode* last = NULL;

        while (temp != NULL)
        {
            BookNode* newBook = new BookNode;

            newBook->bookID = temp->bookID;
            newBook->title = temp->title;
            newBook->author = temp->author;
            newBook->next = NULL;

            if (top == NULL)
            {
                top = newBook;
            }
            else
            {
                last->next = newBook;
            }

            last = newBook;
            temp = temp->next;
            count++;
        }
    }

    Stack& operator=(const Stack& other)
    {
        if (this != &other)
        {
            while (!IsEmpty())
            {
                BookNode* temp = Pop();
                delete temp;
            }

            BookNode* temp = other.top;
            BookNode* last = NULL;

            while (temp != NULL)
            {
                BookNode* newBook = new BookNode;

                newBook->bookID = temp->bookID;
                newBook->title = temp->title;
                newBook->author = temp->author;
                newBook->next = NULL;

                if (top == NULL)
                {
                    top = newBook;
                }
                else
                {
                    last->next = newBook;
                }

                last = newBook;
                temp = temp->next;
                count++;
            }
        }

        return *this;
    }

    ~Stack()
    {
        while (!IsEmpty())
        {
            BookNode* temp = Pop();
            delete temp;
        }
    }
};

int main()
{
    Stack books;

    BookNode* book1 = new BookNode;
    book1->bookID = 101;
    book1->title = "PF";
    book1->author = "MALIK KARAM HUSSAIN";

    BookNode* book2 = new BookNode;
    book2->bookID = 102;
    book2->title = "OOP";
    book2->author = "Karam Hussain";

    BookNode* book3 = new BookNode;
    book3->bookID = 103;
    book3->title = "DBMS";
    book3->author = "KARAM";

    BookNode* book4 = new BookNode;
    book4->bookID = 104;
    book4->title = "DSA";
    book4->author = "KARAM";

    books.Push(book1);
    books.Push(book2);
    books.Push(book3);
    books.Push(book4);

    cout << "All Books:" << endl;
    books.PrintStack();

    cout << endl;

    cout << "Top Book:" << endl;
    BookNode* topBook = books.GetTopValue();

    if (topBook != NULL)
    {
        cout << topBook->bookID << " "
             << topBook->title << " "
             << topBook->author << endl;
    }

    cout << endl;

    cout << "Removing Top Book:" << endl;

    BookNode* removedBook = books.Pop();

    if (removedBook != NULL)
    {
        cout << "Removed: "
             << removedBook->title << endl;

        delete removedBook;
    }

    cout << endl;

    cout << "Books After Pop:" << endl;
    books.PrintStack();

    cout << endl;

    if (books.IsEmpty())
    {
        cout << "Stack is empty." << endl;
    }
    else
    {
        cout << "Stack is not empty." << endl;
    }

    return 0;
}
