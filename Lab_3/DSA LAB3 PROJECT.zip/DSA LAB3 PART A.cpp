#include <iostream>
#include <string>
using namespace std;

struct BookRequestNode
{
    int studentID;
    string studentName;
    int bookID;
    string bookTitle;
    BookRequestNode* next;
};

class Queue
{
private:
    BookRequestNode* front;
    BookRequestNode* rear;
    int count;

public:
    Queue()
    {
        front = NULL;
        rear = NULL;
        count = 0;
    }

    void EnQueue(BookRequestNode* request)
    {
        request->next = NULL;

        if (rear == NULL)
        {
            front = request;
            rear = request;
        }
        else
        {
            rear->next = request;
            rear = request;
        }

        count++;
    }

    BookRequestNode* DeQueue()
    {
        if (front == NULL)
        {
            return NULL;
        }

        BookRequestNode* request = front;
        front = front->next;

        if (front == NULL)
        {
            rear = NULL;
        }

        request->next = NULL;
        count--;

        return request;
    }

    bool IsEmpty()
    {
        return front == NULL;
    }

    bool IsNotEmpty()
    {
        return front != NULL;
    }

    void PrintQueue()
    {
        if (front == NULL)
        {
            cout << "Queue is empty." << endl;
            return;
        }

        BookRequestNode* current = front;

        cout << "\nAll Book Requests" << endl;

        while (current != NULL)
        {
            cout << "\nStudent ID: " << current->studentID << endl;
            cout << "Student Name: " << current->studentName << endl;
            cout << "Book ID: " << current->bookID << endl;
            cout << "Book Title: " << current->bookTitle << endl;

            current = current->next;
        }
    }

    ~Queue()
    {
        while (front != NULL)
        {
            BookRequestNode* temp = front;
            front = front->next;
            delete temp;
        }

        rear = NULL;
    }
};

int main()
{
    Queue requests;
    int choice;

    do
    {
        cout << "\n===== Library Book Request Management System =====" << endl;
        cout << "1. Add Book Request" << endl;
        cout << "2. Serve Next Request" << endl;
        cout << "3. Display All Requests" << endl;
        cout << "4. Check if Queue is Empty" << endl;
        cout << "5. Check if Queue is Not Empty" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1)
        {
            BookRequestNode* request = new BookRequestNode;

            cout << "Enter Student ID: ";
            cin >> request->studentID;

            cin.ignore();

            cout << "Enter Student Name: ";
            getline(cin, request->studentName);

            cout << "Enter Book ID: ";
            cin >> request->bookID;

            cin.ignore();

            cout << "Enter Book Title: ";
            getline(cin, request->bookTitle);

            requests.EnQueue(request);

            cout << "Book request added successfully." << endl;
        }

        else if (choice == 2)
        {
            BookRequestNode* served = requests.DeQueue();

            if (served == NULL)
            {
                cout << "Queue is empty." << endl;
            }
            else
            {
                cout << "\nServed Request" << endl;
                cout << "Student ID: " << served->studentID << endl;
                cout << "Student Name: " << served->studentName << endl;
                cout << "Book ID: " << served->bookID << endl;
                cout << "Book Title: " << served->bookTitle << endl;

                delete served;
            }
        }

        else if (choice == 3)
        {
            requests.PrintQueue();
        }

        else if (choice == 4)
        {
            if (requests.IsEmpty())
            {
                cout << "Queue is empty." << endl;
            }
            else
            {
                cout << "Queue is not empty." << endl;
            }
        }

        else if (choice == 5)
        {
            if (requests.IsNotEmpty())
            {
                cout << "Queue is not empty." << endl;
            }
            else
            {
                cout << "Queue is empty." << endl;
            }
        }

        else if (choice == 6)
        {
            cout << "Program ended." << endl;
        }

        else
        {
            cout << "Invalid choice." << endl;
        }

    } while (choice != 6);

    return 0;
}
