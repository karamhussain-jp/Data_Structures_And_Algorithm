#include <iostream>
#include <string>
using namespace std;

struct RequestNode
{
    int clientID;
    string clientName;
    string serviceName;
    string website;
    RequestNode* next;
};

class Queue
{
private:
    RequestNode* front;
    RequestNode* rear;
    int count;

public:
    Queue()
    {
        front = NULL;
        rear = NULL;
        count = 0;
    }

    void EnQueue(RequestNode* request)
    {
        request->next = NULL;

        if (rear == NULL)
        {
            front = request;
            rear = request;
        }
        else
        {
            rear->next = request;
            rear = request;
        }

        count++;
    }

    RequestNode* DeQueue()
    {
        if (front == NULL)
        {
            return NULL;
        }

        RequestNode* request = front;
        front = front->next;

        if (front == NULL)
        {
            rear = NULL;
        }

        request->next = NULL;
        count--;

        return request;
    }

    bool IsEmpty()
    {
        return front == NULL;
    }

    bool IsNotEmpty()
    {
        return front != NULL;
    }

    void PrintQueue()
    {
        if (front == NULL)
        {
            cout << "Queue is empty." << endl;
            return;
        }

        RequestNode* current = front;

        cout << "\nAll Security Requests" << endl;

        while (current != NULL)
        {
            cout << "\nClient ID: " << current->clientID << endl;
            cout << "Client Name: " << current->clientName << endl;
            cout << "Service Name: " << current->serviceName << endl;
            cout << "Website: " << current->website << endl;

            current = current->next;
        }
    }

    ~Queue()
    {
        while (front != NULL)
        {
            RequestNode* temp = front;
            front = front->next;
            delete temp;
        }

        rear = NULL;
    }
};

int main()
{
    Queue requests;
    int choice;

    do
    {
        cout << "\n===== Cyber Security Request Management System =====" << endl;
        cout << "1. Add Security Request" << endl;
        cout << "2. Process Next Request" << endl;
        cout << "3. Display All Requests" << endl;
        cout << "4. Check if Queue is Empty" << endl;
        cout << "5. Check if Queue is Not Empty" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1)
        {
            RequestNode* request = new RequestNode;

            cout << "Enter Client ID: ";
            cin >> request->clientID;

            cin.ignore();

            cout << "Enter Client Name: ";
            getline(cin, request->clientName);

            cout << "Enter Service Name: ";
            getline(cin, request->serviceName);

            cout << "Enter Website: ";
            getline(cin, request->website);

            requests.EnQueue(request);

            cout << "Request added successfully." << endl;
        }

        else if (choice == 2)
        {
            RequestNode* processed = requests.DeQueue();

            if (processed == NULL)
            {
                cout << "Queue is empty." << endl;
            }
            else
            {
                cout << "\nProcessed Request" << endl;
                cout << "Client ID: " << processed->clientID << endl;
                cout << "Client Name: " << processed->clientName << endl;
                cout << "Service Name: " << processed->serviceName << endl;
                cout << "Website: " << processed->website << endl;

                delete processed;
            }
        }

        else if (choice == 3)
        {
            requests.PrintQueue();
        }

        else if (choice == 4)
        {
            if (requests.IsEmpty())
            {
                cout << "Queue is empty." << endl;
            }
            else
            {
                cout << "Queue is not empty." << endl;
            }
        }

        else if (choice == 5)
        {
            if (requests.IsNotEmpty())
            {
                cout << "Queue is not empty." << endl;
            }
            else
            {
                cout << "Queue is empty." << endl;
            }
        }

        else if (choice == 6)
        {
            cout << "Program ended." << endl;
        }

        else
        {
            cout << "Invalid choice." << endl;
        }

    } while (choice != 6);

    return 0;
}
